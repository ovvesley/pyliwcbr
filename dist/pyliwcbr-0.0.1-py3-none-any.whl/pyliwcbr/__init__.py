from src.liwc import liwc

print(liwc.Liwc("data/dictionaries/liwc_2015_pt2_sem_pulo_linhas.dic"))

__all__ = [
    'liwc'
]