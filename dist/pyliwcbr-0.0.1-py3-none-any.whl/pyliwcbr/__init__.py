import liwc
print(liwc)

__all__ = [
    'liwc'
]