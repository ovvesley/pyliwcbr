from pyliwcbr.src.liwc import liwc

print(liwc.Liwc)

__all__ = [
    'liwc'
]