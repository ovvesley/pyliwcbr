from pyliwcbr.src.liwc import liwc

dic = liwc.Liwc('dic.dic')

sentence = dic.process_sentence("assediaram")

for category in sentence.get_categories():
    print(category.get_tag())