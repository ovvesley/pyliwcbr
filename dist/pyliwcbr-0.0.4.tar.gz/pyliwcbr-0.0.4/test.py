from pyliwcbr.src.liwc import liwc

dic = liwc.Liwc("dic.dic")

sentence = dic.process_sentence("eu te odeio")

categories_sentence = sentence.get_categories()

for category in categories_sentence:
    print(category.get_tag())
    pass